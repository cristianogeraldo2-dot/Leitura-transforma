# 📖 Leitura Diária do Líder

App de liderança e desenvolvimento pessoal com treino personalizado.

---

## 🚀 Como publicar no Vercel (passo a passo)

### 1. Criar conta no GitHub
- Acesse: https://github.com
- Clique em "Sign up" e crie sua conta gratuita

### 2. Subir o projeto no GitHub
- Acesse: https://github.com/new
- Nome do repositório: `leitura-diaria`
- Deixe como **Public**
- Clique em "Create repository"
- Na próxima tela, clique em "uploading an existing file"
- Arraste TODOS os arquivos desta pasta (exceto node_modules se existir)
- Clique em "Commit changes"

### 3. Publicar no Vercel
- Acesse: https://vercel.com
- Clique em "Sign up" → entre com sua conta do GitHub
- Clique em "Add New Project"
- Selecione o repositório `leitura-diaria`
- Clique em "Deploy" (não precisa mudar nada)
- Aguarde 1-2 minutos
- ✅ Seu link estará disponível! Ex: `leitura-diaria.vercel.app`

### 4. Instalar no celular como app
**Android (Chrome):**
- Abra o link no Chrome
- Toque nos 3 pontinhos (canto superior direito)
- Selecione "Adicionar à tela inicial"

**iPhone (Safari):**
- Abra o link no Safari
- Toque no ícone de compartilhar (quadrado com seta)
- Selecione "Adicionar à Tela de Início"

---

## 💰 Como vender

1. Receba o pagamento via PIX ou pelo Kiwify (kiwify.com.br)
2. Envie o link do app pelo WhatsApp
3. O cliente instala na tela inicial e faz o cadastro **uma única vez**
4. Cadastro fica salvo no celular — não precisa refazer nunca

---

## 📱 Funcionalidades

- ✅ Cadastro único por perfil profissional (Líder, Vendedor, Empreendedor, Saúde, Educador)
- ✅ Rotina personalizada por horário (detecta manhã, trabalho, família, treino, noite)
- ✅ Treino gerado automaticamente por objetivo, nível e equipamento
- ✅ Diário interativo com campos de escrita na aba Noite
- ✅ Checklist diário com progresso visual
- ✅ Fundo creme — ideal para leitura neurológica
- ✅ Funciona no celular sem baixar da App Store

---

Dúvidas? Fale com o suporte.
