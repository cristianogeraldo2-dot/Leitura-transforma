import { useState, useRef } from "react";

const C = {
  bg:"#FBF4E3", bgCard:"#F3EAD0", bgDeep:"#EDE0C4",
  border:"#D9CCB0", text:"#2A1F0E", mid:"#5C4A2A",
  soft:"#8C7550", gold:"#8B6010", goldBg:"#F5E6BE", red:"#8B2500",
};
const st = { fontFamily:"'Lato',sans-serif" };
const serif = { fontFamily:"'Cormorant Garamond',serif" };

// ─── GERADOR DE TREINO PERSONALIZADO ─────────────────────────────────────────
const EXERCICIOS = {
  // Academia - por grupo muscular
  peito_gym:    [["Supino Reto","4x10","60s"],["Supino Inclinado","3x12","60s"],["Crucifixo","3x12","45s"],["Crossover","3x15","45s"],["Flexão Fechada","2x falha","30s"]],
  costas_gym:   [["Puxada Frontal","4x10","60s"],["Remada Baixa","4x10","60s"],["Remada Unilateral","3x12","45s"],["Pullover","3x12","45s"],["Encolhimento","3x15","30s"]],
  pernas_gym:   [["Agachamento","4x10","90s"],["Leg Press","4x12","60s"],["Cadeira Extensora","3x15","45s"],["Cadeira Flexora","3x15","45s"],["Panturrilha em Pé","4x20","30s"]],
  ombros_gym:   [["Desenvolvimento","4x10","60s"],["Elevação Lateral","4x12","45s"],["Elevação Frontal","3x12","45s"],["Encolhimento c/ Halteres","3x15","30s"]],
  biceps_gym:   [["Rosca Direta","4x10","45s"],["Rosca Alternada","3x12","45s"],["Rosca Concentrada","3x12","30s"]],
  triceps_gym:  [["Tríceps Corda","4x12","45s"],["Tríceps Testa","3x12","45s"],["Tríceps Coice","3x12","30s"],["Mergulho","2x falha","30s"]],
  full_gym:     [["Agachamento","3x10","60s"],["Supino","3x10","60s"],["Remada","3x10","60s"],["Desenvolvimento","3x12","45s"],["Rosca","3x12","30s"],["Tríceps","3x12","30s"]],
  hiit_gym:     [["Esteira Sprint 30s/30s","8 rounds","—"],["Burpee","3x15","45s"],["Polichinelo","3x30","30s"],["Jumping Squat","3x20","45s"],["Corda (se disponível)","3x1min","30s"]],
  // Casa com halteres
  peito_home:   [["Flexão Normal","4x15","45s"],["Flexão Inclinada","3x12","45s"],["Flexão c/ Haltere","3x12","45s"],["Crucifixo c/ Haltere","3x15","45s"]],
  costas_home:  [["Remada c/ Haltere","4x12","45s"],["Pullover c/ Haltere","3x15","45s"],["Superman","3x20","30s"],["Remada Invertida (cadeira)","3x15","45s"]],
  pernas_home:  [["Agachamento Livre","4x15","45s"],["Agachamento Búlgaro","3x12 cada","60s"],["Avanço","3x12 cada","45s"],["Agachamento Sumô","3x15","45s"],["Panturrilha","4x25","30s"]],
  full_home:    [["Agachamento","3x15","45s"],["Flexão","3x15","45s"],["Remada c/ Haltere","3x12","45s"],["Avanço","3x12","45s"],["Polichinelo","3x30","30s"],["Prancha","3x45s","30s"]],
  hiit_home:    [["Burpee","4x10","45s"],["Mountain Climber","3x30","30s"],["Jumping Squat","3x15","45s"],["Polichinelo","3x30","30s"],["Corrida Estacionária","3x45s","30s"]],
  // Sem equipamento
  peito_body:   [["Flexão Normal","4x20","45s"],["Flexão Inclinada","3x15","45s"],["Flexão Diamante","3x15","45s"],["Flexão Explosiva","3x10","60s"]],
  costas_body:  [["Superman","4x20","30s"],["Remada Invertida","3x15","45s"],["Alongamento Gato-Vaca","3x15","30s"]],
  pernas_body:  [["Agachamento","4x20","45s"],["Avanço","4x15 cada","45s"],["Agachamento Sumô","3x20","45s"],["Elevação de Quadril","4x20","30s"],["Panturrilha","4x30","30s"]],
  full_body:    [["Agachamento","3x20","45s"],["Flexão","3x15","45s"],["Avanço","3x12","45s"],["Mountain Climber","3x20","30s"],["Superman","3x15","30s"],["Prancha","3x40s","30s"]],
  hiit_body:    [["Burpee","4x10","45s"],["Mountain Climber","4x20","30s"],["Jumping Squat","4x15","45s"],["Polichinelo","3x40","30s"],["Corrida Estacionária","4x30s","30s"]],
};

const AQUECIMENTO = ["5 min caminhada/bicicleta leve","Mobilidade articular — pescoço, ombros, quadril","10 polichinelos leves","Respiração profunda — prepara mente e corpo"];
const DESACELERACAO = ["5 min caminhada leve","Alongamento dos grupos trabalhados","Respiração profunda x5","Beba água — hidratação pós-treino"];

function gerarTreinoDia(dados, diaSemanaNr) {
  const { objetivo, nivel, diasTreino, equipamento } = dados;
  const eq = equipamento === "gym" ? "_gym" : equipamento === "home" ? "_home" : "_body";
  const diasNum = parseInt(diasTreino);

  // Mapear dias da semana em dias de treino
  const diasTreinoMap = {
    3: { 1:"full", 3:"full", 5:"full" },
    4: { 1:"peito+triceps", 2:"pernas", 4:"costas+biceps", 5:"ombros+hiit" },
    5: { 1:"peito+triceps", 2:"pernas", 3:"costas+biceps", 4:"ombros", 5:"hiit" },
    6: { 1:"peito+triceps", 2:"pernas", 3:"costas+biceps", 4:"ombros+hiit", 5:"peito+triceps", 6:"pernas" },
  };

  const mapa = diasTreinoMap[diasNum] || diasTreinoMap[3];
  const tipo = mapa[diaSemanaNr]; // 0=dom,1=seg...6=sab

  if (!tipo) return null; // dia de descanso

  // Montar exercícios
  let exercicios = [];
  if (tipo === "full") {
    exercicios = EXERCICIOS[`full${eq}`] || EXERCICIOS.full_body;
  } else if (tipo.includes("hiit")) {
    exercicios = EXERCICIOS[`hiit${eq}`] || EXERCICIOS.hiit_body;
  } else {
    const grupos = tipo.split("+");
    grupos.forEach(g => {
      const key = `${g}${eq}`;
      if (EXERCICIOS[key]) exercicios = [...exercicios, ...EXERCICIOS[key].slice(0,3)];
    });
  }

  // Ajustar por nível
  if (nivel === "iniciante") {
    exercicios = exercicios.slice(0,4).map(e => [e[0], e[1].replace(/x\d+/g, m => "x" + Math.max(8, parseInt(m.slice(1))-4)), e[2]]);
  } else if (nivel === "avancado") {
    exercicios = exercicios.map(e => {
      const sets = e[1].match(/\d+x/)?.[0];
      const newSets = sets ? (parseInt(sets)+1) + "x" : "";
      return [e[0], e[1].replace(/^\d+x/, newSets), e[2]];
    });
  }

  // Nome do treino
  const nomes = {
    "full":"Treino Full Body","peito+triceps":"Peito + Tríceps",
    "pernas":"Pernas","costas+biceps":"Costas + Bíceps",
    "ombros":"Ombros","ombros+hiit":"Ombros + HIIT","hiit":"HIIT Cardio",
    "peito+triceps+ombros":"Empurrar","full":"Treino Total",
  };
  const nomeTreino = nomes[tipo] || tipo.replace(/\+/g," + ").replace(/\b\w/g,l=>l.toUpperCase());
  const objetivo_txt = { emagrecer:"🔥 Foco em queimar","hipertrofia":"💪 Foco em crescer","condicionamento":"⚡ Foco em resistência","saude":"💚 Foco em saúde" }[objetivo] || "";

  return { nome: nomeTreino, objetivo_txt, exercicios, tipo };
}

function nomeDia(nr) {
  return ["Domingo","Segunda","Terça","Quarta","Quinta","Sexta","Sábado"][nr];
}

// ─── PERFIS ───────────────────────────────────────────────────────────────────
const PERFIS = {
  lider:        { nome:"Líder / Gestor",         icone:"🏆", cor:"#1A3A6B", perguntaManha:"Que tipo de líder meu time vai ver hoje?", perguntaTarde:"Estou desenvolvendo pessoas ou apenas cobrando?", perguntaNoite:"Hoje eu fui o líder que meu time merece?", ensinamentos:[{tema:"Gestor vs Líder Transformador",conteudo:"O gestor cobra — o líder transforma. Gestor é como o cobrador do ônibus: só pede o bilhete. Líder transformador é o motorista: conhece o destino, cuida dos passageiros e garante que todos cheguem.",acao:"Quando foi a última vez que você ajudou alguém crescer sem cobrar nada em troca?"},{tema:"O Espírito dos 300",conteudo:"Time que compete internamente é como um exército que aponta a espada pro soldado ao lado. Time dos 300 aponta a espada pro inimigo — juntos.",acao:"Quem no seu time está precisando do seu escudo hoje?"},{tema:"Pertencimento Autêntico",conteudo:"Pertencimento é como raiz de árvore: invisível, mas é ela que segura tudo quando a tempestade vem. Metas são galhos — importantes, mas caem sem raiz.",acao:"Que ação concreta você vai fazer esta semana para criar pertencimento?"},{tema:"Autoridade Conquistada",conteudo:"Autoridade não vem do cargo. Vem da consistência, do exemplo e da presença real na vida da equipe. Você só é autoridade quando vive aquilo que fala.",acao:"Há coerência entre o que você fala e o que você pratica?"},{tema:"Liderança como Sal e Luz",conteudo:"Sal: você não vê, mas sente falta quando não tem. Luz: quando acende, todo mundo enxerga. Líderes que formam deixam marca que nunca sai.",acao:"Que marca você está deixando na vida de cada pessoa do seu time?"}], checklist:{ manha:["Âncora espiritual — oração antes do celular","15 min leitura de liderança","Defini as 3 prioridades de gestão","Planejei quem vou desenvolver hoje"], tarde:["Reconheci 1 pessoa publicamente","Tive 1 conversa de desenvolvimento","Check: gerando cultura ou apagando fogo?","Identifiquei 1 problema e propus solução"], noite:["3 gratidões + 1 aprendizado","Família — presente de verdade","Revisei resultados do time","Dormi bem — 7h mínimo"] } },
  vendedor:     { nome:"Vendedor / Captador",     icone:"🎯", cor:"#2A5C3A", perguntaManha:"Quantas famílias vou ajudar a realizar um sonho hoje?", perguntaTarde:"Estou sendo solução ou apenas fazendo contatos?", perguntaNoite:"Fui honesto e excelente com cada cliente?", ensinamentos:[{tema:"Narrativa Pessoal na Captação",conteudo:"Sem narrativa, o captador é um funcionário. Com narrativa conectada ao seu sonho, ele é um protagonista. Protagonista não precisa ser cobrado — ele corre atrás.",acao:"Por que você está neste trabalho? Onde quer estar em 2 anos?"},{tema:"Hospitalidade como Valor",conteudo:"Hospitalidade não é protocolo. É uma postura de vida. Receber o cliente como alguém que importa — não como uma tarefa a cumprir.",acao:"Como você vai receber o próximo cliente como se fosse o mais importante?"},{tema:"Consciência de Conversão",conteudo:"Qual é sua taxa de conversão hoje? Defina UMA ação para melhorar esta semana. Ação vira hábito vira resultado.",acao:"Qual ÚNICO comportamento vai mudar sua conversão esta semana?"},{tema:"Você é Maior que a Objeção",conteudo:"A objeção não é o inimigo — é onde você prova quem é. O que muda não é o tamanho da objeção, é a sua capacidade de respondê-la.",acao:"Qual objeção do cliente está te travando? Como você é maior do que ela?"},{tema:"Propósito Individual",conteudo:"Colaboradores com propósito claro entregam mais. Quando o trabalho muda a vida de famílias, ele deixa de ser obrigação e vira missão.",acao:"O que o seu trabalho hoje significa para as famílias dos seus clientes?"}], checklist:{ manha:["Âncora espiritual — antes do celular","Revisei minha meta — sei onde estou","Defini quantos contatos farei hoje","Mentalidade: sou solução, não vendedor"], tarde:["Fiz minha cota de contatos","Fui honesto com cada cliente","Aprendi com 1 negativa de hoje","Check: resultado ou apenas movimento?"], noite:["3 gratidões + 1 aprendizado","Família — presente de verdade","Revisei minha performance do dia","Preparei amanhã mentalmente"] } },
  empreendedor: { nome:"Empreendedor",            icone:"🚀", cor:"#8B4A00", perguntaManha:"Qual decisão de hoje vai impactar meu negócio em 5 anos?", perguntaTarde:"Estou construindo empresa ou apagando incêndio?", perguntaNoite:"Avancei hoje ou apenas sobrevivi?", ensinamentos:[{tema:"Mentalidade de Dono",conteudo:"Alta performance não é ausência de dificuldades — é a capacidade de transformar dificuldades em movimento. Líderes não esperam o problema desaparecer — eles se movem enquanto o problema existe.",acao:"Qual decisão você está postergando que precisa ser tomada hoje?"},{tema:"Você é Maior que o Problema",conteudo:"O criador é sempre maior do que a criatura. Se o problema nasceu da sua empresa, você tem o que precisa para resolvê-lo.",acao:"Nomeie seu maior problema agora com clareza. Problema sem nome é ansiedade."},{tema:"Visão + Execução",conteudo:"Toda empresa que deu certo foi melhorando a cada entrega. O que foi errado foi corrigido. Credibilidade se constrói entregando sempre mais do que prometeu.",acao:"O que você prometeu que ainda não entregou?"},{tema:"Ciclo de Alta Performance",conteudo:"Consciência: onde está o negócio? Movimento: uma ação concreta esta semana. Repetição: sistematizar o que funciona. Otimização: a cada 30 dias, o que cortar?",acao:"Qual sistema do seu negócio mais precisa de otimização?"},{tema:"Liderança que Multiplica",conteudo:"Você não escala sozinho. A empresa escala pela equipe. O líder que não forma outros, cria dependência — não legado.",acao:"Quem do seu time você está formando para o próximo nível?"}], checklist:{ manha:["Âncora espiritual — antes do celular","Revisei as métricas principais","Defini a decisão mais importante hoje","Planejei quem do time vou desenvolver"], tarde:["Tomei a decisão mais importante","Conversei com 1 cliente","Check: estratégico ou operacional?","Gerei o ambiente da equipe"], noite:["3 gratidões + 1 aprendizado","Família — desconectei do negócio","Revisei finanças — sei meus números","Planejei amanhã com clareza"] } },
  saude:        { nome:"Saúde / Coach",           icone:"💚", cor:"#8B2500", perguntaManha:"Hoje vou cuidar do meu corpo ou negligenciá-lo?", perguntaTarde:"Estou pregando o que pratico?", perguntaNoite:"Meu corpo e mente foram tratados como prioridade?", ensinamentos:[{tema:"Corpo como Instrumento",conteudo:"Saúde é combustível de liderança. O líder que não cuida do corpo logo pede ao corpo para parar. Alta performance física e mental caminham juntas.",acao:"Como seu estado físico hoje está impactando sua presença?"},{tema:"Consciência de Performance",conteudo:"Alta performance é um ciclo. Consciência: onde está meu corpo? Movimento: uma mudança de cada vez. Repetição: ação vira hábito. Otimização: mais com menos energia.",acao:"Qual hábito físico, mantido por 90 dias, vai mudar tudo?"},{tema:"Você é Maior que a Desculpa",conteudo:"A desculpa mais comum é falta de tempo. A verdade é que todos têm 24 horas. Alta performance começa quando você para de gerenciar tempo e começa a gerenciar energia.",acao:"Qual desculpa você usa para não cuidar do seu corpo?"},{tema:"Recuperação é Performance",conteudo:"Sono de qualidade é decisão de alta performance. Descanso e alegria de viver são combustível — não luxo.",acao:"Você está dormindo 7h? O que precisa mudar hoje?"},{tema:"Disciplina como Identidade",conteudo:"Não espere motivação para agir. Aja para criar motivação. Disciplina não é força de vontade — é identidade.",acao:"Qual ritual diário define quem você é como profissional?"}], checklist:{ manha:["Hidratação — água antes de qualquer coisa","Movimento matinal — 20 a 30 min","Intenção: quem vou impactar hoje?","Revisei planejamento de treinos/sessões"], tarde:["Comi bem — combustível para performance","Check de energia — como estou agora?","Apliquei o que sei ao meu próprio corpo?","Conexão com cliente além do técnico"], noite:["3 gratidões + 1 aprendizado","Telas desligadas 30 min antes de dormir","Revisei recuperação — sono, alimentação","Família — presente e desconectado"] } },
  educador:     { nome:"Educador / Professor",    icone:"📚", cor:"#1A5C6B", perguntaManha:"Qual aluno posso impactar de forma diferente hoje?", perguntaTarde:"Ensinei ou apenas transmiti conteúdo?", perguntaNoite:"Alguém vai dormir diferente por causa de mim hoje?", ensinamentos:[{tema:"Liderança na Sala de Aula",conteudo:"Professor que só transmite conteúdo é um manual ambulante. Professor transformador conecta o conteúdo à vida do aluno. Quando o aluno entende o porquê, o aprendizado é irreversível.",acao:"Qual aluno está perdido e precisa de uma conexão diferente?"},{tema:"Narrativa que Ensina",conteudo:"A história por trás de um conceito vale mais que o conceito isolado. O educador que conta sua história de superação vira uma prova social viva.",acao:"Qual história de vida você pode usar hoje para ensinar o que o livro não consegue?"},{tema:"Pertencimento na Turma",conteudo:"Alunos que pertencem aprendem mais. Pertencimento é invisível mas é o que segura tudo quando a pressão vem.",acao:"Qual aluno está se sentindo excluído na sua turma hoje?"},{tema:"Você é Maior que a Dificuldade",conteudo:"Turmas difíceis, sistemas falhos, recursos escassos — o educador de alta performance não espera as condições ideais. Age com o que tem.",acao:"Qual dificuldade do sistema está te impedindo de ser o melhor educador?"},{tema:"Presença como Ferramenta",conteudo:"Sua presença é seu maior instrumento. Alunos sentem quando o professor está presente ou apenas cumprindo protocolo.",acao:"Qual foi a última vez que um aluno disse que sua aula mudou algo?"}], checklist:{ manha:["Âncora espiritual — antes do celular","Revisei o plano de aula com intenção real","Defini qual aluno vou observar especialmente","Entrei preparado para transformar alguém"], tarde:["Conectei conteúdo à vida de 1 aluno","Reconheci 1 avanço de um aluno","Check: ensinei ou cumpri currículo?","Conversei com 1 colega — conexão real"], noite:["3 gratidões + 1 aprendizado","Família — desconectei da escola","15 min de leitura — minha formação não para","Dormi bem — amanhã preciso de presença total"] } },
};

const FRASES = [
  {t:"Metas levam a um lugar. Missão define um destino.",f:"DNA Alta Performance"},
  {t:"Líderes transformadores não gerenciam tarefas — transformam vidas.",f:"DNA Alta Performance"},
  {t:"Alta performance não tem linha de chegada. Crescimento é processo, não destino.",f:"DNA Alta Performance"},
  {t:"Você nasceu para gerar solução. A criatura nunca é maior que o criador.",f:"Geraldo Rufino"},
  {t:"Todo mundo tem problema. A diferença está em quem você acredita ser diante dele.",f:"Geraldo Rufino"},
  {t:"O líder que não reflete não aprende. O que não aprende repete.",f:"Método ENCARNA"},
  {t:"Protagonismo começa antes da primeira reunião.",f:"Método Diário GAV"},
  {t:"O corpo forte suporta os dias difíceis. Cuide dele hoje para liderar amanhã.",f:"Método Diário"},
];

const PILARES = [
  {nome:"Deus",cor:"#B8860B",desc:"Âncora espiritual — oração antes do celular"},
  {nome:"Saúde",cor:"#8B2500",desc:"Treino e movimento — combustível de liderança"},
  {nome:"Família",cor:"#5C3A8B",desc:"Tempo presente — sem telas, sem trabalho"},
  {nome:"Trabalho",cor:"#1A3A6B",desc:"3 prioridades diárias — impacto real"},
  {nome:"Ambiente",cor:"#2A5C3A",desc:"Você é o termostato do seu ambiente"},
  {nome:"Conhecimento",cor:"#1A5C6B",desc:"15 min de leitura + 1 insight por dia"},
  {nome:"Amigos",cor:"#8B4A00",desc:"Reconheça 1 pessoa — conexão gera lealdade"},
  {nome:"Finanças",cor:"#4A6B1A",desc:"2 min de consciência financeira diária"},
];

// ─── ONBOARDING ───────────────────────────────────────────────────────────────
function Onboarding({ onConcluir }) {
  const [step, setStep] = useState(0);
  const [dados, setDados] = useState({
    nome:"", empresa:"", perfil:"lider",
    acordar:"04:30", trabInicio:"06:00", trabFim:"17:00",
    familiaLabel:"Família", academiaHora:"20:00", treinoLabel:"Academia",
    objetivo:"hipertrofia", nivel:"intermediario", diasTreino:"4", equipamento:"gym",
  });

  const refs = {
    nome:useRef(), empresa:useRef(), acordar:useRef(), trabInicio:useRef(),
    trabFim:useRef(), familiaLabel:useRef(), academiaHora:useRef(), treinoLabel:useRef(),
  };

  const lerRefs = () => {
    const d = {...dados};
    Object.keys(refs).forEach(k => { if (refs[k].current) d[k] = refs[k].current.value; });
    return d;
  };

  const set = (k,v) => setDados(p => ({...p,[k]:v}));

  const avancar = () => {
    const d = lerRefs(); setDados(d);
    if (step < 5) setStep(s => s+1);
    else onConcluir(d);
  };

  const Input = ({label,campo,placeholder,type="text"}) => (
    <div style={{marginBottom:18}}>
      <p style={{...st,fontSize:10,letterSpacing:2,color:C.gold,textTransform:"uppercase",fontWeight:700,marginBottom:6}}>{label}</p>
      <input ref={refs[campo]} type={type} defaultValue={dados[campo]} placeholder={placeholder}
        style={{width:"100%",padding:"13px 14px",background:"#fff",border:`1.5px solid ${C.border}`,borderRadius:10,fontSize:16,color:C.text,...st,outline:"none"}} />
    </div>
  );

  const Opcao = ({label,valor,campo,desc,ic}) => (
    <div onClick={() => set(campo,valor)} style={{
      display:"flex",alignItems:"center",gap:12,padding:"13px 16px",
      background: dados[campo]===valor ? C.goldBg : C.bgCard,
      border:`2px solid ${dados[campo]===valor ? C.gold : C.border}`,
      borderRadius:12,cursor:"pointer",marginBottom:8,transition:"all .2s",
    }}>
      {ic && <span style={{fontSize:22}}>{ic}</span>}
      <div style={{flex:1}}>
        <p style={{...st,fontSize:14,fontWeight:700,color:dados[campo]===valor?C.gold:C.text}}>{label}</p>
        {desc && <p style={{...st,fontSize:11,color:C.soft,marginTop:2}}>{desc}</p>}
      </div>
      {dados[campo]===valor && <span style={{color:C.gold,fontSize:18,fontWeight:700}}>✓</span>}
    </div>
  );

  const steps = [
    // 0 — Boas-vindas
    <div key="bv" style={{textAlign:"center",padding:"10px 0"}}>
      <div style={{fontSize:56,marginBottom:16}}>📖</div>
      <h1 style={{...serif,fontSize:34,fontWeight:400,color:C.text,lineHeight:1.2,marginBottom:12}}>
        Leitura<br/><span style={{fontStyle:"italic",color:C.gold}}>Diária do Líder</span>
      </h1>
      <p style={{...st,fontSize:14,color:C.mid,lineHeight:1.8,maxWidth:300,margin:"0 auto 20px"}}>
        Conteúdo diário + treino personalizado para <strong>você</strong>.
      </p>
      <div style={{background:C.goldBg,borderLeft:`3px solid ${C.gold}`,borderRadius:"0 10px 10px 0",padding:"14px 18px",textAlign:"left"}}>
        <p style={{...serif,fontSize:16,fontStyle:"italic",color:C.text,lineHeight:1.7}}>"Alta performance não tem linha de chegada. Crescimento é processo, não destino."</p>
      </div>
    </div>,

    // 1 — Perfil
    <div key="perf">
      <h2 style={{...serif,fontSize:26,fontWeight:400,color:C.text,marginBottom:6}}>Qual é o seu perfil?</h2>
      <p style={{...st,fontSize:13,color:C.soft,marginBottom:18,lineHeight:1.7}}>O conteúdo diário vai ser adaptado para a sua profissão.</p>
      {Object.entries(PERFIS).map(([id,p]) => <Opcao key={id} label={p.nome} valor={id} campo="perfil" desc={p.icone+" "+p.perguntaManha} />)}
    </div>,

    // 2 — Quem é você
    <div key="nome">
      <h2 style={{...serif,fontSize:26,fontWeight:400,color:C.text,marginBottom:6}}>Quem é você?</h2>
      <p style={{...st,fontSize:13,color:C.soft,marginBottom:22,lineHeight:1.7}}>O app vai usar seu nome para personalizar.</p>
      <Input label="Seu nome" campo="nome" placeholder="Ex: Carlos, Maria..." />
      <Input label="Sua empresa / organização" campo="empresa" placeholder="Ex: GAV Resorts..." />
    </div>,

    // 3 — Horários
    <div key="hor">
      <h2 style={{...serif,fontSize:26,fontWeight:400,color:C.text,marginBottom:6}}>Sua rotina de horários</h2>
      <p style={{...st,fontSize:13,color:C.soft,marginBottom:18,lineHeight:1.7}}>O app abre no bloco certo conforme o horário.</p>
      <Input label="Acorda" campo="acordar" type="time" />
      <Input label="Começa o trabalho" campo="trabInicio" type="time" />
      <Input label="Termina o trabalho" campo="trabFim" type="time" />
      <Input label="Hora do treino" campo="academiaHora" type="time" />
      <Input label="Nome do treino (ex: Academia, Crossfit...)" campo="treinoLabel" placeholder="Academia" />
      <Input label="Nome do tempo em família (ex: Família, Casa...)" campo="familiaLabel" placeholder="Família" />
    </div>,

    // 4 — Objetivo do treino
    <div key="obj">
      <h2 style={{...serif,fontSize:26,fontWeight:400,color:C.text,marginBottom:6}}>Seu objetivo no treino</h2>
      <p style={{...st,fontSize:13,color:C.soft,marginBottom:18,lineHeight:1.7}}>O treino do dia vai ser montado para o seu objetivo.</p>
      <Opcao label="Emagrecer" valor="emagrecer" campo="objetivo" ic="🔥" desc="Queima de gordura e condicionamento" />
      <Opcao label="Hipertrofia" valor="hipertrofia" campo="objetivo" ic="💪" desc="Ganho de massa muscular" />
      <Opcao label="Condicionamento" valor="condicionamento" campo="objetivo" ic="⚡" desc="Resistência física e disposição" />
      <Opcao label="Saúde e bem-estar" valor="saude" campo="objetivo" ic="💚" desc="Movimento, qualidade de vida, longevidade" />
    </div>,

    // 5 — Nível e equipamento
    <div key="niv">
      <h2 style={{...serif,fontSize:26,fontWeight:400,color:C.text,marginBottom:6}}>Nível e equipamento</h2>
      <p style={{...st,fontSize:10,letterSpacing:2,color:C.gold,textTransform:"uppercase",fontWeight:700,marginBottom:10,marginTop:4}}>Seu nível atual</p>
      <Opcao label="Iniciante" valor="iniciante" campo="nivel" desc="Até 6 meses de treino regular" />
      <Opcao label="Intermediário" valor="intermediario" campo="nivel" desc="6 meses a 2 anos de treino" />
      <Opcao label="Avançado" valor="avancado" campo="nivel" desc="Mais de 2 anos de treino consistente" />
      <p style={{...st,fontSize:10,letterSpacing:2,color:C.gold,textTransform:"uppercase",fontWeight:700,marginBottom:10,marginTop:20}}>Dias de treino por semana</p>
      <div style={{display:"flex",gap:8,marginBottom:20}}>
        {["3","4","5","6"].map(d => (
          <div key={d} onClick={() => set("diasTreino",d)} style={{
            flex:1,padding:"12px",textAlign:"center",borderRadius:10,cursor:"pointer",
            background: dados.diasTreino===d ? C.goldBg : C.bgCard,
            border:`2px solid ${dados.diasTreino===d ? C.gold : C.border}`,
          }}>
            <p style={{...st,fontSize:20,fontWeight:700,color:dados.diasTreino===d?C.gold:C.text}}>{d}</p>
            <p style={{...st,fontSize:9,color:C.soft}}>dias</p>
          </div>
        ))}
      </div>
      <p style={{...st,fontSize:10,letterSpacing:2,color:C.gold,textTransform:"uppercase",fontWeight:700,marginBottom:10}}>Onde você treina?</p>
      <Opcao label="Academia (equipada)" valor="gym" campo="equipamento" ic="🏋️" desc="Musculação, máquinas, halteres, barras" />
      <Opcao label="Casa com halteres" valor="home" campo="equipamento" ic="🏠" desc="Halteres, elásticos, espaço limitado" />
      <Opcao label="Sem equipamento" valor="body" campo="equipamento" ic="🤸" desc="Apenas peso corporal, em qualquer lugar" />
    </div>,
  ];

  const podeAvancar = step===1 ? !!dados.perfil : step===2 ? true : true;

  return (
    <div style={{minHeight:"100vh",background:C.bg}}>
      <style>{`@import url('https://fonts.googleapis.com/css2?family=Cormorant+Garamond:ital,wght@0,400;1,400&family=Lato:wght@400;700&display=swap');*{box-sizing:border-box;margin:0;padding:0;}`}</style>
      <div style={{maxWidth:440,margin:"0 auto",padding:"32px 22px 80px"}}>
        {step>0 && (
          <div style={{marginBottom:22}}>
            <div style={{display:"flex",justifyContent:"space-between",marginBottom:5}}>
              <p style={{...st,fontSize:10,color:C.soft}}>Passo {step} de 5</p>
              <p style={{...st,fontSize:10,color:C.gold,fontWeight:700}}>{step*20}%</p>
            </div>
            <div style={{background:C.border,borderRadius:10,height:5}}>
              <div style={{background:C.gold,height:"100%",borderRadius:10,width:`${step*20}%`,transition:"width .4s"}}/>
            </div>
          </div>
        )}
        {steps[step]}
        <div style={{display:"flex",gap:10,marginTop:28}}>
          {step>0 && <button onClick={() => setStep(s=>s-1)} style={{flex:1,padding:"14px",background:C.bgCard,border:`1.5px solid ${C.border}`,borderRadius:12,...st,fontSize:15,color:C.mid,cursor:"pointer",fontWeight:700}}>← Voltar</button>}
          <button onClick={avancar} disabled={!podeAvancar} style={{flex:2,padding:"14px",background:podeAvancar?C.gold:C.border,border:"none",borderRadius:12,...st,fontSize:15,color:"#fff",fontWeight:700,cursor:podeAvancar?"pointer":"not-allowed"}}>
            {step===0?"Começar →":step===5?"✓ Abrir meu app":"Próximo →"}
          </button>
        </div>
      </div>
    </div>
  );
}

// ─── APP PRINCIPAL ────────────────────────────────────────────────────────────
export default function App() {
  // ── Cadastro único via localStorage ──
  const [cfg, setCfg] = useState(() => {
    try { const s = localStorage.getItem("ldr_cfg"); return s ? JSON.parse(s) : null; } catch { return null; }
  });
  const [checks, setChecks] = useState(() => {
    try {
      const hoje = new Date().toDateString();
      const s = localStorage.getItem("ldr_checks");
      if (s) { const p = JSON.parse(s); return p.data === hoje ? p.checks : {}; }
    } catch {}
    return {};
  });
  const [diario, setDiario] = useState(() => {
    try {
      const hoje = new Date().toDateString();
      const s = localStorage.getItem("ldr_diario");
      if (s) { const p = JSON.parse(s); return p.data === hoje ? p.diario : { g1:"",g2:"",g3:"",aprendizado:"",melhoria:"",intencao:"" }; }
    } catch {}
    return { g1:"",g2:"",g3:"",aprendizado:"",melhoria:"",intencao:"" };
  });
  const [pilar,setPilar]   = useState(null);
  const [conf,setConf]     = useState(false);
  const [aba,setAba]       = useState("manha");
  const [diarioSalvo,setDiarioSalvo] = useState(false);

  const salvarCfg = (d) => {
    try { localStorage.setItem("ldr_cfg", JSON.stringify(d)); } catch {}
    setCfg(d);
  };
  const salvarChecks = (novo) => {
    try { localStorage.setItem("ldr_checks", JSON.stringify({ data: new Date().toDateString(), checks: novo })); } catch {}
    setChecks(novo);
  };
  const toggle = k => { const novo = {...checks,[k]:!checks[k]}; salvarChecks(novo); };

  const setD = (k,v) => {
    const novo = {...diario,[k]:v};
    setDiario(novo);
    setDiarioSalvo(false);
    try { localStorage.setItem("ldr_diario", JSON.stringify({ data: new Date().toDateString(), diario: novo })); } catch {}
  };

  if (!cfg) return <Onboarding onConcluir={d => {
    const ph = s => parseInt(s.split(":")[0]);
    const h  = new Date().getHours();
    let ini  = "noite";
    if (h>=ph(d.acordar)&&h<ph(d.trabInicio))     ini="manha";
    else if (h>=ph(d.trabInicio)&&h<ph(d.trabFim)) ini="trab";
    else if (h>=ph(d.trabFim)&&h<ph(d.academiaHora)) ini="fam";
    else if (h>=ph(d.academiaHora)&&h<ph(d.academiaHora)+1) ini="treino";
    setAba(ini); salvarCfg(d);
  }} />;

  const perfil  = PERFIS[cfg.perfil] || PERFIS.lider;
  const hoje    = new Date();
  const dia     = hoje.getDate();
  const diaS    = hoje.getDay();
  const frase   = FRASES[dia % FRASES.length];
  const ensino  = perfil.ensinamentos[dia % perfil.ensinamentos.length];
  const ds      = ["Dom","Seg","Ter","Qua","Qui","Sex","Sáb"][diaS];
  const ms      = ["Jan","Fev","Mar","Abr","Mai","Jun","Jul","Ago","Set","Out","Nov","Dez"][hoje.getMonth()];
  const treino  = gerarTreinoDia(cfg, diaS);

  const TABS = [
    {id:"manha",  ic:"🌅", lb:"Manhã",         hr:cfg.acordar.slice(0,5)},
    {id:"trab",   ic:"💼", lb:"Trabalho",       hr:cfg.trabInicio.slice(0,5)},
    {id:"fam",    ic:"🏠", lb:cfg.familiaLabel, hr:cfg.trabFim.slice(0,5)},
    {id:"treino", ic:"🏋️",lb:cfg.treinoLabel,  hr:cfg.academiaHora.slice(0,5)},
    {id:"noite",  ic:"🌙", lb:"Noite",          hr:"21h+"},
  ];

  const toggle = k => setChecks(p=>({...p,[k]:!p[k]}));
  const allK   = [...perfil.checklist.manha,...perfil.checklist.tarde,...perfil.checklist.noite].map((_,i)=>`c${i}`);
  const pct    = Math.round(allK.filter(k=>checks[k]).length/allK.length*100);

  const Chk = ({id,txt}) => (
    <div onClick={()=>toggle(id)} style={{display:"flex",alignItems:"flex-start",gap:14,padding:"13px 0",borderBottom:`1px solid ${C.border}`,cursor:"pointer"}}>
      <div style={{width:22,height:22,borderRadius:"50%",flexShrink:0,marginTop:1,border:checks[id]?"none":`2px solid ${C.gold}`,background:checks[id]?C.gold:"transparent",display:"flex",alignItems:"center",justifyContent:"center",transition:"all .2s"}}>
        {checks[id]&&<span style={{color:"#fff",fontSize:12,fontWeight:700}}>✓</span>}
      </div>
      <p style={{...st,fontSize:15,lineHeight:1.65,color:checks[id]?C.soft:C.text,textDecoration:checks[id]?"line-through":"none"}}>{txt}</p>
    </div>
  );
  const SL = ({ch}) => <p style={{...st,fontSize:9,letterSpacing:2.5,color:C.soft,textTransform:"uppercase",marginBottom:14,marginTop:26,borderBottom:`1px solid ${C.border}`,paddingBottom:8,fontWeight:700}}>{ch}</p>;
  const PB = ({lb,txt}) => (
    <div style={{background:C.goldBg,borderLeft:`3px solid ${C.gold}`,borderRadius:"0 10px 10px 0",padding:"16px 20px",marginTop:20}}>
      {lb&&<p style={{...st,fontSize:9,letterSpacing:2,color:C.gold,textTransform:"uppercase",marginBottom:8,fontWeight:700}}>{lb}</p>}
      <p style={{...serif,fontSize:18,fontStyle:"italic",lineHeight:1.7,color:C.text}}>{txt}</p>
    </div>
  );
  const BC = ({ic,tit,sub,desc}) => (
    <div style={{background:C.bgCard,border:`1px solid ${C.border}`,borderRadius:12,padding:"16px 18px",marginBottom:12}}>
      <div style={{display:"flex",alignItems:"center",gap:10,marginBottom:10}}>
        <span style={{fontSize:22}}>{ic}</span>
        <div>
          <p style={{...st,fontSize:10,color:C.gold,letterSpacing:1.5,textTransform:"uppercase",fontWeight:700}}>{tit}</p>
          {sub&&<p style={{...st,fontSize:10,color:C.soft,marginTop:1}}>{sub}</p>}
        </div>
      </div>
      <p style={{...st,fontSize:15,lineHeight:1.85,color:C.mid}}>{desc}</p>
    </div>
  );

  if (conf) return (
    <div style={{minHeight:"100vh",background:C.bg,maxWidth:440,margin:"0 auto",padding:"32px 22px 80px"}}>
      <style>{`@import url('https://fonts.googleapis.com/css2?family=Cormorant+Garamond:ital,wght@0,400;1,400&family=Lato:wght@400;700&display=swap');*{box-sizing:border-box;margin:0;padding:0;}`}</style>
      <div style={{display:"flex",alignItems:"center",gap:12,marginBottom:24}}>
        <button onClick={()=>setConf(false)} style={{background:"none",border:"none",cursor:"pointer",fontSize:22,color:C.gold}}>←</button>
        <h2 style={{...serif,fontSize:26,fontWeight:400,color:C.text}}>Configurações</h2>
      </div>
      <div style={{background:C.bgCard,border:`1px solid ${C.border}`,borderRadius:14,padding:"20px",marginBottom:16}}>
        <div style={{display:"flex",alignItems:"center",gap:10,marginBottom:6}}>
          <span style={{fontSize:28}}>{perfil.icone}</span>
          <div>
            <p style={{...st,fontSize:9,color:C.soft,textTransform:"uppercase",letterSpacing:1.5,fontWeight:700}}>{perfil.nome}</p>
            <p style={{...st,fontSize:20,fontWeight:700,color:C.text}}>{cfg.nome}</p>
          </div>
        </div>
        {cfg.empresa&&<p style={{...st,fontSize:13,color:C.mid}}>{cfg.empresa}</p>}
      </div>
      {[
        {l:"Objetivo",   v:{emagrecer:"🔥 Emagrecer",hipertrofia:"💪 Hipertrofia",condicionamento:"⚡ Condicionamento",saude:"💚 Saúde"}[cfg.objetivo]},
        {l:"Nível",      v:{iniciante:"Iniciante",intermediario:"Intermediário",avancado:"Avançado"}[cfg.nivel]},
        {l:"Dias/semana",v:cfg.diasTreino+" dias"},
        {l:"Equipamento",v:{gym:"Academia",home:"Casa c/ halteres",body:"Sem equipamento"}[cfg.equipamento]},
        {l:"Trabalho",   v:`${cfg.trabInicio} → ${cfg.trabFim}`},
        {l:cfg.treinoLabel,v:cfg.academiaHora},
      ].map((r,i)=>(
        <div key={i} style={{display:"flex",justifyContent:"space-between",padding:"12px 16px",background:C.bgCard,border:`1px solid ${C.border}`,borderRadius:10,marginBottom:8}}>
          <p style={{...st,fontSize:13,color:C.mid}}>{r.l}</p>
          <p style={{...st,fontSize:14,fontWeight:700,color:C.gold}}>{r.v}</p>
        </div>
      ))}
      <button onClick={()=>{try{localStorage.removeItem("ldr_cfg");localStorage.removeItem("ldr_checks");localStorage.removeItem("ldr_diario");}catch(e){}setCfg(null);}} style={{width:"100%",marginTop:20,padding:"14px",background:"#FFF0EB",border:`1.5px solid ${C.red}40`,borderRadius:12,...st,fontSize:14,color:C.red,cursor:"pointer",fontWeight:700}}>Reconfigurar do zero</button>
    </div>
  );

  return (
    <div style={{minHeight:"100vh",background:C.bg}}>
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Cormorant+Garamond:ital,wght@0,400;0,600;1,400&family=Lato:wght@400;700&display=swap');
        *{box-sizing:border-box;margin:0;padding:0;}
        ::-webkit-scrollbar{width:4px}::-webkit-scrollbar-thumb{background:${C.gold}60;border-radius:4px}
        .tp{background:transparent;border:none;cursor:pointer;padding:7px 0;flex:1;display:flex;flex-direction:column;align-items:center;gap:2px;}
        .tp.on{background:${C.goldBg};}
        .tl{font-family:'Lato',sans-serif;font-size:9px;letter-spacing:.8px;text-transform:uppercase;color:${C.soft};font-weight:700;}
        .tp.on .tl{color:${C.gold};}
        .th{font-family:'Lato',sans-serif;font-size:8px;color:${C.border};}
        .tp.on .th{color:${C.gold}80;}
      `}</style>
      <div style={{maxWidth:460,margin:"0 auto"}}>

        {/* HEADER */}
        <div style={{padding:"20px 20px 16px",background:C.bgDeep,borderBottom:`2px solid ${C.border}`}}>
          <div style={{display:"flex",justifyContent:"space-between",alignItems:"flex-start"}}>
            <div>
              <div style={{display:"flex",alignItems:"center",gap:6,marginBottom:4}}>
                <span style={{fontSize:16}}>{perfil.icone}</span>
                <p style={{...st,fontSize:9,letterSpacing:2,color:C.gold,textTransform:"uppercase",fontWeight:700}}>{perfil.nome}</p>
              </div>
              <h1 style={{...serif,fontSize:26,fontWeight:400,color:C.text,lineHeight:1.15}}>
                Olá, <span style={{fontStyle:"italic",color:C.gold}}>{cfg.nome}</span>
              </h1>
              {cfg.empresa&&<p style={{...st,fontSize:11,color:C.soft,marginTop:2}}>{cfg.empresa}</p>}
            </div>
            <div style={{textAlign:"right"}}>
              <p style={{...serif,fontSize:36,fontWeight:400,color:C.text,lineHeight:1}}>{dia}</p>
              <p style={{...st,fontSize:10,color:C.soft,letterSpacing:1,marginTop:2}}>{ds} · {ms}</p>
              <div style={{marginTop:8,display:"flex",alignItems:"center",gap:8,justifyContent:"flex-end"}}>
                <div>
                  <p style={{...st,fontSize:9,color:C.soft,marginBottom:4,fontWeight:700}}>{pct}%</p>
                  <div style={{background:C.border,borderRadius:10,height:4,width:66}}>
                    <div style={{background:C.gold,height:"100%",borderRadius:10,width:`${pct}%`,transition:"width .5s"}}/>
                  </div>
                </div>
                <button onClick={()=>setConf(true)} style={{background:"none",border:`1px solid ${C.border}`,borderRadius:8,padding:"4px 8px",cursor:"pointer",fontSize:14,color:C.soft}}>⚙</button>
              </div>
            </div>
          </div>
          <div style={{marginTop:14,padding:"13px 16px",background:C.bgCard,border:`1px solid ${C.border}`,borderLeft:`3px solid ${C.gold}`,borderRadius:"0 10px 10px 0"}}>
            <p style={{...serif,fontSize:16,fontStyle:"italic",lineHeight:1.6,color:C.text,marginBottom:8}}>"{frase.t}"</p>
            <p style={{...st,fontSize:9,color:C.gold,letterSpacing:2,textTransform:"uppercase",fontWeight:700}}>— {frase.f}</p>
          </div>
        </div>

        {/* TABS */}
        <div style={{display:"flex",borderBottom:`2px solid ${C.border}`,background:C.bgCard,position:"sticky",top:0,zIndex:10}}>
          {TABS.map(t=>(
            <button key={t.id} className={`tp ${aba===t.id?"on":""}`} onClick={()=>setAba(t.id)}>
              <span style={{fontSize:15}}>{t.ic}</span>
              <span className="tl">{t.lb}</span>
              <span className="th">{t.hr}</span>
            </button>
          ))}
        </div>

        <div style={{padding:"4px 20px 100px",background:C.bg}}>

          {/* MANHÃ */}
          {aba==="manha"&&<div>
            <SL ch={`Ritual da Manhã · ${cfg.acordar} – ${cfg.trabInicio}`}/>
            <p style={{...st,fontSize:13,color:C.mid,fontStyle:"italic",marginBottom:18,lineHeight:1.8}}>"Este é o dia que o Senhor fez; alegremo-nos e nos regozijemos nele." — Sl 118:24</p>
            <BC ic="🙏" tit="Âncora Espiritual" sub={`${cfg.acordar} · 5 min`} desc="Antes do celular. 3 respirações, agradecimento, 1 oração. Pergunta: Quem eu quero ser hoje?" />
            <BC ic="📖" tit="Alimentação Mental" sub="15 min de leitura" desc="Liderança, desenvolvimento ou tema da sua área. Anote 1 insight aplicável ao seu dia." />
            <BC ic="🎯" tit="3 Prioridades do Dia" sub="10 min" desc="P1: O que só EU posso fazer hoje? P2: Quem precisa de mim? P3: O que vou aprender?" />
            <BC ic="🚀" tit="Vai pro campo" sub={`${cfg.trabInicio} · Início`} desc="Mente preparada. Prioridades definidas. Entra no modo protagonista — não no modo reativo." />
            <SL ch="Check · Manhã"/>
            {perfil.checklist.manha.map((txt,i)=><Chk key={i} id={`c${i}`} txt={txt}/>)}
            <PB lb="Pergunta da Manhã" txt={perfil.perguntaManha}/>
          </div>}

          {/* TRABALHO */}
          {aba==="trab"&&<div>
            <SL ch={`No Campo · ${cfg.trabInicio} – ${cfg.trabFim}`}/>
            <BC ic="⚡" tit="Chegada com Intenção" sub={cfg.trabInicio} desc="Qual energia você vai gerar hoje? Você é o termostato — não o termômetro do ambiente." />
            <BC ic="🤝" tit="Conexão Humana" sub="Almoço · 15 min" desc="Almoce com alguém — sem pauta, apenas presença. 1 pergunta genuína sobre a vida da pessoa." />
            <BC ic="🧭" tit="Check do Meio-Dia" sub="5 min" desc="Estou nas 3 prioridades? Estou sendo quem eu disse que seria esta manhã?" />
            <BC ic="🌟" tit="Reconhecimento" sub="Tarde" desc="Reconheça 1 pessoa. Identifique 1 problema e proponha solução — não só aponte." />
            <SL ch="Check · Trabalho"/>
            {perfil.checklist.tarde.map((txt,i)=><Chk key={i} id={`c${perfil.checklist.manha.length+i}`} txt={txt}/>)}
            <SL ch="Ensino do Dia"/>
            <div style={{background:C.bgCard,border:`1px solid ${C.border}`,borderRadius:14,padding:"20px"}}>
              <span style={{display:"inline-block",background:C.goldBg,color:C.gold,borderRadius:20,padding:"3px 14px",...st,fontSize:9,letterSpacing:1.5,textTransform:"uppercase",fontWeight:700,marginBottom:14}}>{perfil.nome}</span>
              <h3 style={{...serif,fontSize:21,fontWeight:600,marginBottom:14,lineHeight:1.3,color:C.text}}>{ensino.tema}</h3>
              <p style={{...st,fontSize:15,lineHeight:1.9,color:C.mid,marginBottom:16}}>{ensino.conteudo}</p>
              <div style={{borderTop:`1px solid ${C.border}`,paddingTop:14}}>
                <p style={{...st,fontSize:9,color:C.gold,letterSpacing:2,textTransform:"uppercase",marginBottom:8,fontWeight:700}}>Pergunta Prática</p>
                <p style={{...serif,fontSize:17,fontStyle:"italic",color:C.text,lineHeight:1.7}}>"{ensino.acao}"</p>
              </div>
            </div>
            <PB lb="Pergunta da Tarde" txt={perfil.perguntaTarde}/>
          </div>}

          {/* FAMÍLIA */}
          {aba==="fam"&&<div>
            <SL ch={`${cfg.familiaLabel} · ${cfg.trabFim} – ${cfg.academiaHora}`}/>
            <p style={{...st,fontSize:13,color:C.mid,fontStyle:"italic",marginBottom:18,lineHeight:1.8}}>Você deu seu dia ao trabalho. Agora dê estas horas para quem mais importa.</p>
            <BC ic="📵" tit="Celular no Silencioso" sub={`${cfg.trabFim} – ${cfg.academiaHora}`} desc="Presente de verdade. Sem notificações de trabalho. Este tempo é sagrado." />
            <BC ic="🍽️" tit="Conexão Real" sub="Sem telas" desc="Pergunte: 'O que foi bom no seu dia?' Ouça. 15 min de presença genuína valem mais que horas físicas ausentes." />
            <BC ic="🏋️" tit={`Prep para ${cfg.treinoLabel}`} sub={`Antes das ${cfg.academiaHora}`} desc="Hidrate bem. Alimentação pré-treino. Vai com energia para o treino." />
            <SL ch={`Check · ${cfg.familiaLabel}`}/>
            <Chk id="f0" txt="Celular no silencioso — presente de verdade"/>
            <Chk id="f1" txt="Perguntei 'O que foi bom no seu dia?' e ouvi"/>
            <PB lb="Lembrete" txt="O líder que cuida bem de casa, cuida melhor do time."/>
          </div>}

          {/* TREINO ── bloco principal */}
          {aba==="treino"&&<div>
            <SL ch={`${cfg.treinoLabel} · ${cfg.academiaHora} · ${nomeDia(diaS)}`}/>

            {treino ? (<>
              {/* Cabeçalho do treino */}
              <div style={{background:`${C.red}08`,border:`1.5px solid ${C.red}30`,borderRadius:14,padding:"18px 20px",marginBottom:16}}>
                <p style={{...st,fontSize:9,letterSpacing:2,color:C.red,textTransform:"uppercase",fontWeight:700,marginBottom:6}}>Treino de Hoje</p>
                <h2 style={{...serif,fontSize:26,fontWeight:600,color:C.text,lineHeight:1.2,marginBottom:6}}>{treino.nome}</h2>
                <div style={{display:"flex",gap:8,flexWrap:"wrap",marginTop:8}}>
                  <span style={{...st,fontSize:11,background:C.goldBg,color:C.gold,borderRadius:20,padding:"3px 12px",fontWeight:700}}>{treino.objetivo_txt}</span>
                  <span style={{...st,fontSize:11,background:"#F0F8FF",color:C.blue||"#1A3A6B",borderRadius:20,padding:"3px 12px",fontWeight:700}}>{cfg.nivel==="iniciante"?"Iniciante":cfg.nivel==="avancado"?"Avançado":"Intermediário"}</span>
                  <span style={{...st,fontSize:11,background:"#F0FFF4",color:"#2A5C3A",borderRadius:20,padding:"3px 12px",fontWeight:700}}>{cfg.equipamento==="gym"?"🏋️ Academia":cfg.equipamento==="home"?"🏠 Casa":"🤸 Sem equip."}</span>
                </div>
              </div>

              {/* Aquecimento */}
              <div style={{background:C.bgCard,border:`1px solid ${C.border}`,borderRadius:12,padding:"16px 18px",marginBottom:12}}>
                <p style={{...st,fontSize:10,color:"#2A5C3A",letterSpacing:1.5,textTransform:"uppercase",fontWeight:700,marginBottom:12}}>🌡️ Aquecimento · 5–8 min</p>
                {AQUECIMENTO.map((a,i)=>(
                  <div key={i} style={{display:"flex",gap:10,alignItems:"flex-start",marginBottom:8}}>
                    <span style={{...st,fontSize:13,color:C.gold,fontWeight:700,minWidth:18}}>{i+1}.</span>
                    <p style={{...st,fontSize:14,color:C.mid,lineHeight:1.5}}>{a}</p>
                  </div>
                ))}
              </div>

              {/* Exercícios */}
              <p style={{...st,fontSize:10,letterSpacing:2,color:C.red,textTransform:"uppercase",fontWeight:700,marginBottom:12,marginTop:20}}>💪 Exercícios Principais</p>
              <div style={{background:C.bgCard,border:`1px solid ${C.border}`,borderRadius:12,overflow:"hidden",marginBottom:12}}>
                <div style={{display:"grid",gridTemplateColumns:"1fr auto auto",padding:"10px 16px",background:C.bgDeep,borderBottom:`1px solid ${C.border}`}}>
                  <p style={{...st,fontSize:9,color:C.soft,textTransform:"uppercase",letterSpacing:1.5,fontWeight:700}}>Exercício</p>
                  <p style={{...st,fontSize:9,color:C.soft,textTransform:"uppercase",letterSpacing:1.5,fontWeight:700,textAlign:"center",minWidth:70}}>Séries/Reps</p>
                  <p style={{...st,fontSize:9,color:C.soft,textTransform:"uppercase",letterSpacing:1.5,fontWeight:700,textAlign:"center",minWidth:45}}>Pausa</p>
                </div>
                {treino.exercicios.map(([nome,sr,pausa],i)=>(
                  <div key={i} style={{display:"grid",gridTemplateColumns:"1fr auto auto",padding:"13px 16px",borderBottom:i<treino.exercicios.length-1?`1px solid ${C.border}`:"none",background:i%2===0?"transparent":C.bg}}>
                    <p style={{...st,fontSize:14,color:C.text,fontWeight:i===0?700:400}}>{nome}</p>
                    <p style={{...st,fontSize:14,color:C.gold,fontWeight:700,textAlign:"center",minWidth:70}}>{sr}</p>
                    <p style={{...st,fontSize:12,color:C.soft,textAlign:"center",minWidth:45}}>{pausa}</p>
                  </div>
                ))}
              </div>

              {/* Desaceleração */}
              <div style={{background:C.bgCard,border:`1px solid ${C.border}`,borderRadius:12,padding:"16px 18px",marginBottom:16}}>
                <p style={{...st,fontSize:10,color:C.gold,letterSpacing:1.5,textTransform:"uppercase",fontWeight:700,marginBottom:12}}>🧘 Desaceleração · 5 min</p>
                {DESACELERACAO.map((a,i)=>(
                  <div key={i} style={{display:"flex",gap:10,alignItems:"flex-start",marginBottom:8}}>
                    <span style={{...st,fontSize:13,color:C.gold,fontWeight:700,minWidth:18}}>{i+1}.</span>
                    <p style={{...st,fontSize:14,color:C.mid,lineHeight:1.5}}>{a}</p>
                  </div>
                ))}
              </div>

              {/* Check treino */}
              <SL ch={`Check · ${cfg.treinoLabel}`}/>
              <Chk id="a0" txt="Aquecimento feito — corpo preparado"/>
              <Chk id="a1" txt="Treinei com foco — sem checar o celular"/>
              <Chk id="a2" txt="Hidratei bem antes, durante e depois"/>
              <Chk id="a3" txt="Desaceleração e alongamento feitos"/>

              <div style={{background:"#FFF0EB",borderLeft:`3px solid ${C.red}`,borderRadius:"0 10px 10px 0",padding:"16px 20px",marginTop:20}}>
                <p style={{...st,fontSize:9,letterSpacing:2,color:C.red,textTransform:"uppercase",marginBottom:8,fontWeight:700}}>Disciplina de Alta Performance</p>
                <p style={{...serif,fontSize:17,fontStyle:"italic",lineHeight:1.7,color:C.text}}>"O corpo forte suporta os dias difíceis. Cuide dele hoje para liderar amanhã."</p>
              </div>

              {/* Próximos dias */}
              <SL ch="Seus dias de treino esta semana"/>
              <div style={{display:"flex",gap:6}}>
                {[1,2,3,4,5,6,0].map(d=>{
                  const diasTreinoMap={3:{1:true,3:true,5:true},4:{1:true,2:true,4:true,5:true},5:{1:true,2:true,3:true,4:true,5:true},6:{1:true,2:true,3:true,4:true,5:true,6:true}};
                  const mapa=diasTreinoMap[parseInt(cfg.diasTreino)]||diasTreinoMap[3];
                  const temTreino=!!mapa[d];
                  const isHoje=d===diaS;
                  return(
                    <div key={d} style={{flex:1,textAlign:"center",padding:"8px 4px",borderRadius:8,background:isHoje?C.gold:temTreino?C.bgCard:"transparent",border:isHoje?`none`:`1px solid ${temTreino?C.border:"transparent"}`}}>
                      <p style={{...st,fontSize:9,color:isHoje?"#fff":temTreino?C.text:C.border,fontWeight:700}}>{"SMTQQS S"[d]}</p>
                      <p style={{fontSize:12,marginTop:2}}>{temTreino?"💪":"—"}</p>
                    </div>
                  );
                })}
              </div>

            </>) : (
              /* Dia de descanso */
              <div style={{textAlign:"center",padding:"40px 20px"}}>
                <div style={{fontSize:52,marginBottom:16}}>😌</div>
                <h2 style={{...serif,fontSize:24,fontWeight:400,color:C.text,marginBottom:12}}>Dia de Descanso</h2>
                <p style={{...st,fontSize:14,color:C.mid,lineHeight:1.8,maxWidth:280,margin:"0 auto 20px"}}>Descanso é parte do treino. O músculo cresce na recuperação, não na academia.</p>
                <div style={{background:C.goldBg,borderLeft:`3px solid ${C.gold}`,borderRadius:"0 10px 10px 0",padding:"14px 18px",textAlign:"left"}}>
                  <p style={{...st,fontSize:10,letterSpacing:2,color:C.gold,textTransform:"uppercase",fontWeight:700,marginBottom:8}}>Dica do dia de descanso</p>
                  <p style={{...serif,fontSize:16,fontStyle:"italic",color:C.text,lineHeight:1.7}}>"Caminhada leve, alongamento, hidratação. O corpo que descansa bem, treina melhor amanhã."</p>
                </div>
                <p style={{...st,fontSize:12,color:C.soft,marginTop:20}}>Próximo treino: {Object.keys({3:{1:true,3:true,5:true},4:{1:true,2:true,4:true,5:true},5:{1:true,2:true,3:true,4:true,5:true},6:{1:true,2:true,3:true,4:true,5:true,6:true}}[parseInt(cfg.diasTreino)]||{}).map(d=>["Dom","Seg","Ter","Qua","Qui","Sex","Sáb"][d]).join(", ")}</p>
              </div>
            )}
          </div>}

          {/* NOITE */}
          {aba==="noite"&&<div>
            <SL ch="Ritual da Noite · 21h – 22h"/>
            <p style={{...st,fontSize:13,color:C.mid,fontStyle:"italic",marginBottom:18,lineHeight:1.8}}>"Seja forte e corajoso. Não se apavore nem desanime, pois o Senhor, o seu Deus, estará com você." — Js 1:9</p>

            <SL ch="Diário do Líder · Escreva agora"/>

            {/* 3 GRATIDÕES */}
            <div style={{background:C.bgCard,border:`1px solid ${C.border}`,borderRadius:12,padding:"16px 18px",marginBottom:12}}>
              <p style={{...st,fontSize:9,letterSpacing:2,color:C.gold,textTransform:"uppercase",marginBottom:4,fontWeight:700}}>🙏 3 Gratidões</p>
              <p style={{...serif,fontSize:14,fontStyle:"italic",color:C.soft,marginBottom:12}}>O que aconteceu de bom hoje?</p>
              {[
                {k:"g1",ph:"Gratidão 1 — ex: Uma conversa que me marcou..."},
                {k:"g2",ph:"Gratidão 2 — ex: Consegui cumprir minha prioridade..."},
                {k:"g3",ph:"Gratidão 3 — ex: Minha família está bem..."},
              ].map(({k,ph})=>(
                <textarea key={k} value={diario[k]} onChange={e=>setD(k,e.target.value)} placeholder={ph} rows={2}
                  style={{width:"100%",padding:"10px 12px",background:"#fff",border:`1.5px solid ${diario[k]?C.gold:C.border}`,borderRadius:8,fontSize:14,color:C.text,...st,outline:"none",resize:"none",lineHeight:1.6,marginBottom:8,transition:"border .2s"}}
                />
              ))}
            </div>

            {/* 1 APRENDIZADO */}
            <div style={{background:C.bgCard,border:`1px solid ${C.border}`,borderRadius:12,padding:"16px 18px",marginBottom:12}}>
              <p style={{...st,fontSize:9,letterSpacing:2,color:C.gold,textTransform:"uppercase",marginBottom:4,fontWeight:700}}>💡 1 Aprendizado</p>
              <p style={{...serif,fontSize:14,fontStyle:"italic",color:C.soft,marginBottom:12}}>O que o dia me ensinou?</p>
              <textarea value={diario.aprendizado} onChange={e=>setD("aprendizado",e.target.value)}
                placeholder="Ex: Aprendi que devo ouvir mais antes de responder..."
                rows={3} style={{width:"100%",padding:"10px 12px",background:"#fff",border:`1.5px solid ${diario.aprendizado?C.gold:C.border}`,borderRadius:8,fontSize:14,color:C.text,...st,outline:"none",resize:"none",lineHeight:1.6,transition:"border .2s"}}
              />
            </div>

            {/* 1 MELHORIA */}
            <div style={{background:C.bgCard,border:`1px solid ${C.border}`,borderRadius:12,padding:"16px 18px",marginBottom:12}}>
              <p style={{...st,fontSize:9,letterSpacing:2,color:C.gold,textTransform:"uppercase",marginBottom:4,fontWeight:700}}>⚡ 1 Melhoria</p>
              <p style={{...serif,fontSize:14,fontStyle:"italic",color:C.soft,marginBottom:12}}>O que farei diferente amanhã?</p>
              <textarea value={diario.melhoria} onChange={e=>setD("melhoria",e.target.value)}
                placeholder="Ex: Vou acordar 15 min antes para ter mais calma..."
                rows={3} style={{width:"100%",padding:"10px 12px",background:"#fff",border:`1.5px solid ${diario.melhoria?C.gold:C.border}`,borderRadius:8,fontSize:14,color:C.text,...st,outline:"none",resize:"none",lineHeight:1.6,transition:"border .2s"}}
              />
            </div>

            {/* 1 INTENÇÃO */}
            <div style={{background:C.bgCard,border:`1px solid ${C.border}`,borderRadius:12,padding:"16px 18px",marginBottom:16}}>
              <p style={{...st,fontSize:9,letterSpacing:2,color:C.gold,textTransform:"uppercase",marginBottom:4,fontWeight:700}}>🌅 1 Intenção</p>
              <p style={{...serif,fontSize:14,fontStyle:"italic",color:C.soft,marginBottom:12}}>Como quero que seja amanhã?</p>
              <textarea value={diario.intencao} onChange={e=>setD("intencao",e.target.value)}
                placeholder="Ex: Quero estar mais presente com o meu time..."
                rows={3} style={{width:"100%",padding:"10px 12px",background:"#fff",border:`1.5px solid ${diario.intencao?C.gold:C.border}`,borderRadius:8,fontSize:14,color:C.text,...st,outline:"none",resize:"none",lineHeight:1.6,transition:"border .2s"}}
              />
            </div>

            {/* Botão salvar / progresso */}
            {(diario.g1||diario.g2||diario.g3||diario.aprendizado||diario.melhoria||diario.intencao) && (
              <div style={{marginBottom:4}}>
                {diarioSalvo ? (
                  <div style={{background:"#F0FFF4",border:`1.5px solid #2A5C3A`,borderRadius:12,padding:"14px 18px",display:"flex",alignItems:"center",gap:10}}>
                    <span style={{fontSize:20}}>✅</span>
                    <p style={{...st,fontSize:14,color:"#2A5C3A",fontWeight:700}}>Diário de hoje salvo! Boa noite, {cfg.nome}.</p>
                  </div>
                ) : (
                  <button onClick={()=>setDiarioSalvo(true)} style={{width:"100%",padding:"14px",background:C.gold,border:"none",borderRadius:12,...st,fontSize:15,color:"#fff",fontWeight:700,cursor:"pointer"}}>
                    ✓ Fechar o dia — Salvar reflexão
                  </button>
                )}
              </div>
            )}
            <SL ch="Check · Noite"/>
            {perfil.checklist.noite.map((txt,i)=><Chk key={i} id={`c${perfil.checklist.manha.length+perfil.checklist.tarde.length+i}`} txt={txt}/>)}
            <SL ch="8 Pilares · Radar Semanal"/>
            <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:8,marginBottom:20}}>
              {PILARES.map((p,i)=>(
                <div key={i} onClick={()=>setPilar(pilar===i?null:i)} style={{cursor:"pointer",borderRadius:10,padding:"12px",border:pilar===i?`1px solid ${p.cor}60`:`1px solid ${C.border}`,background:pilar===i?`${p.cor}10`:C.bgCard,transition:"all .2s"}}>
                  <div style={{width:8,height:8,borderRadius:"50%",background:p.cor,marginBottom:7}}/>
                  <p style={{...st,fontSize:12,fontWeight:700,color:pilar===i?p.cor:C.text,marginBottom:pilar===i?5:0}}>{p.nome}</p>
                  {pilar===i&&<p style={{...st,fontSize:12,lineHeight:1.6,color:C.mid}}>{p.desc}</p>}
                </div>
              ))}
            </div>
            <PB lb="Pergunta Final do Dia" txt={`"${perfil.perguntaNoite}"`}/>
          </div>}

          <div style={{marginTop:44,textAlign:"center",paddingTop:24,borderTop:`2px solid ${C.border}`}}>
            <p style={{...serif,fontSize:14,fontStyle:"italic",color:C.mid,lineHeight:1.9}}>"A questão não é se você pode alcançar alta performance.<br/>A questão é: você está disposto a se tornar quem precisa ser?"</p>
            <p style={{...st,fontSize:9,color:C.soft,letterSpacing:2,marginTop:12,textTransform:"uppercase",fontWeight:700}}>{cfg.empresa||"Leitura Diária do Líder"}</p>
          </div>
        </div>
      </div>
    </div>
  );
}
